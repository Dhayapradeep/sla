let box = document.getElementById("box");
        let button = document.getElementById("colorBtn");

        button.addEventListener("click", function() {
            box.classList.toggle("green");
        });