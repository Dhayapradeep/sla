let text = document.getElementById("text");
        let button = document.getElementById("toggleBtn");

        button.addEventListener("click", function() {
            text.classList.toggle("show");
        });